





NOTE: Do you think you downloaded this from a website that's using an adf.ly link to ILLEGALLY pay someone else for my work? Then visit my official Strongestcraft thread on the Minecraft forums and report them to me ASAP, please. Thanks in advance for your help! If you're not sure: compare the adf.ly link you used to any of the adf.ly download links in the official thread. If they're not the same, then either their links are outdated ones of mine or they're the links of someone who's committing fraud. Here's a link to the thread you should report them on: http://www.minecraftforum.net/viewtopic.php?f=1021&t=171726






The latest version of this pack can always be found here: http://www.minecraftforum.net/viewtopic.php?f=1021&t=171726

Customized for Tekkit and TerraFirmaCraft as of July 2012!

An alternative texture pack that's a lot like Strongestcraft+, but without the x-ray aspects, is Assistcraft, great for general use! If you love using the default texture pack, you'll love Assistcraft even more! http://www.minecraftforum.net/topic/372683-16x173assistcraftupdated-7-31-1130-am-cdt/

If you didn't already know, equipping a pumpkin as a helmet with this texture pack may enhance your night vision, depending on your brightness, contrast and gamma settings. Try it and see for yourself!


HOW TO INSTALL:


For Windows Vista/7 users:
1: Go to C:\Users\[Your Name]\AppData\Roaming\.minecraft\texturepacks
2: Cut this entire .zip folder to the texturepacks folder under .minecraft. Make sure that you DON'T extract the files! Again, you're NOT supposed to remove the files from this .zip folder! Cut the ENTIRE FOLDER and paste it into the above location.
3: Close the folder, start up the game, log in.
4: Under "Mods & Texture Packs," select this texture pack, then click "Done."
5: Enjoy!


For Windows XP users:
1: Go to C:\Documents and Settings\[Your Name]\Application Data\.minecraft\texturepacks
2: Cut this entire .zip folder to the texturepacks folder under .minecraft. Make sure that you DON'T extract the files! Again, you're NOT supposed to remove the files from this .zip folder! Cut the ENTIRE FOLDER and paste it into the above location.
3: Close the folder, start up the game, log in.
4: Under "Mods & Texture Packs," select this texture pack, then click "Done."
5: Enjoy!


For Mac users:
1: Follow the steps in this guide:
http://www.minecraftforum.net/viewtopic.php?f=25&t=40207
2: Alternatively, here are different instructions from another mac owner! "What you have to do is compress all the items inside the folder, not the folder itself, so navigate to the Strongestcraft+ folder but DON'T zip it, go into it and zip all of the items inside it. To do this, just highlight all the files and folders inside it, right click any of them and click "Compress 29 items" (I think that's how many, but if not it's close.) Finally, just put that zipped folder into the "texturepacks" folder in your minecraft folder, hope I could help."
3: Enjoy!


For Ubuntu users:
1: Go to your home folder and press ctrl+H. This will reveal any hidden files and folders.
2: Double click your .minecraft folder, then the texturepacks inside of it, and paste the Strongestcraft zip file in.
3: Close the folder, start up the game, log in.
4: Under "Mods & Texture Packs," select this texture pack, then click "Done."
5: Enjoy!